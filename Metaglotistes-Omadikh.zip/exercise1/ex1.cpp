#include <cstdio>
#include <bits/stdc++.h>
using namespace std;

void checkseq(stack <string> s) {
    int numx=0;
    stack <string> state;
    //Αρχικοποίηση στοίβας αυτομάτου
    state.push("$");
    //Προώθηση αρχικού συμβόλου "$" στην στοίβα αυτομάτου
    while(!s.empty()) {
        //Έλεγχος εάν η ακολουθία εισόδου είναι άδεια
        if ((s.top() == "x" || s.top() == "X")&&!state.empty()) {
            /*Έλεγχος για :
             * 1) αν ο επόμενος χαρακτήρας της ακολουθίας εισόδου είναι "Χ" (ή "X" κεφαλαίο)
             * 2) αν η στοίβα αυτομάτου δεν είναι άδεια */
            numx++;
            state.push("A");
            //Προσθήκη συμβόλου "Α" στην στοίβα
            printf("The difference between the number of X's and Y's currently is: %i \n", numx);
        }
        else if ((s.top() == "y" || s.top() == "Y")&&state.top()=="A") {
            /*Έλεγχος για :
             * 1) αν ο επόμενος χαρακτήρας της ακολουθίας εισόδου είναι "y" (ή "Y" κεφαλαίο)
             * 2) αν το ανώτερο σύμβολο της στοίβας αυτομάτου είναι "A" */
            numx--;
            state.pop();
            //Αφαίρεση του πιο πάνω συμβόλου της στοίβας
            printf("The difference between the number of X's and Y's currently is: %i \n", numx);
        }
        else{
            /*Εάν κανένα από τα δύο παραπάνω σενάρια δεν πραγματοποιηθεί, τότε η ακολουθία του
            χρήστη είναι λανθασμένη. Ο αλγόριθμος σταματάει και ένα μήνυμα ενημέρωσης του
             χρήστη για το λάθος εμφανίζεται στην οθόνη */
            string f =s.top();
            printf("This sequence is not acceptable, cause of the character: %s \n", f.c_str());
            break;
        }
        if (state.empty()){
            /*Εάν η στοίβα αυτομάτου είναι άδεια, τότε σε κάποιο σημείο η ακολουθία είχε μεγαλύτερο
            αριθμό Υ από Χ, δηλαδή η ακολουθία είναι λανθασμένη. Ο αλγόριθμος θα παύσει και αργότερα
             θα εκτυπωθεί μήνυμα λάθους στην οθόνη */
            break;
        }
        s.pop();
    }
    if(state.top()!="$"){
        /*Εάν η στοίβα αυτομάτου δεν έχει το δολλάριο ως το ανώτερο (και μοναδικό) σύμβολο, η ακολουθία
        του χρήστη είναι λανθασμένη, καθώς είτε η διαφορά του πλήθους των "Χ" από τα "Υ" σε κάποιο σημείο
         είναι αρνητική, ή υπάρχει έλλειψη από "Υ" στο τέλος της ακολουθίας. */
        printf("This sequence is incorrect, because the difference between the number of X's and Y's, at least at a certain point, is lower than 0, or is missing Y's at the end of the sequence \n");
    }
    else if(!s.empty()){
        /*Εάν ο αλγόριθμος τελείωσε πριν σαρώσει όλους τους χαρακτήρες της ακολουθίας του χρήστη
         τότε η ακολουθια περιέχει κάποιο λάθος, όπως έναν μη ανιχεύσιμο χαρακτήρα π.χ."τ" */
        printf("This sequence is incorrect \n");
    }
    else{
        //Εάν κανένας από τους παραπάνω ελέγχους δεν βρει παρασπονδία, τότε η ακολουθία είναι σωστή
        printf("This sequence is correct \n");
    }
}

int main() {
    stack <string> stk;
    //Αρχικοποίηση στοίβας όπου θα εισαχθεί η ακολουθία του χρήστη
    string str,x;
    int i;
    printf("Type the sequence of x and y you want to check \n");
    //Παράκληση στον χρήστη να δώσει ακουλουθία για έλεγχο
    cin>>str;
    for (i = str.length(); i --> 0;)
    {
        x = str.at(i);
        stk.push(x);
    }
    /* Εισαγωγή των χαρακτήρων της ακολουθίας εισόδου του χρήστη, έναν έναν, στην στοίβα ανάποδα
    (από τον τελεύταίο έως τον πρώτο), ώστε να ελεγχθεί η ακολουθία με την σωστή σειρά */
    checkseq(stk);
    return 0;
}

