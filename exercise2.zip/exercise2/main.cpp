#include <iostream>
#include <random>
#include <ctime>
#include <cstdlib>
#include <chrono>
using namespace std;

void test(string generate, int imax){
    /*δημιουργούμε μια γεννήτρια παραγωγής τυχαίων συμβόλων, ωστε να μπορέσουμε να διαλέξουμε τυχαία
     * ποιά εφαρμογή των κανόνων παραγωγής θα διαλέξουμε για κανόνες παραγωγής οι οποίοι έχουν
     * πολλές εφαρμογές για τα ίδια αριστερά μέλη */
    auto now =chrono::system_clock::now();
    auto time1 =chrono::time_point_cast<chrono::milliseconds>(now);
    auto epoch = time1.time_since_epoch();
    long duration = epoch.count();
    srand(duration);
    int x,y;
    //δημιουργούμε ένα όριο επαναλήψεων που μπορούμε να επιλέξομε τυχαία εφαρμογές κανόνων παραγωγής
    if(imax<25){
        imax++;
        x=rand()%2;
        y=rand()%3;
    }
    else{
        /*Εάν χτυπήσουμε στο όριο τότε αναγκάζουμε την εφαρμογή να επιλέξει τον χαρακτήρα "ν" και το κενό
        αντίστοιχα ώστε να τερματίσει η εφαρμογή το ταχύτερο */
        x=0;
        y=0;
    }
    size_t occurrence1 = generate.find('E');
    //Εύρεση της θέσης του πρώτου πιο αριστερού σημείου (αν υπάρχει) του μη τερματικού συμβόλου "Ε"
    size_t occurrence2 = generate.find('Y');
    //Εύρεση της θέσης του πρώτου πιο αριστερού σημείου (αν υπάρχει) του μη τερματικού συμβόλου "Υ"
    size_t occurrence3 = generate.find('A');
    //Εύρεση της θέσης του πρώτου πιο αριστερού σημείου (αν υπάρχει) του μη τερματικού συμβόλου "Α"
    size_t occurrence4 = generate.find('B');
    //Εύρεση της θέσης του πρώτου πιο αριστερού σημείου (αν υπάρχει) του μη τερματικού συμβόλου "Β"

    //Έλεγχος για τον κανόνα που θα εφαρμόσουμε
    if(occurrence1!=string::npos){
        generate.replace(occurrence1,1,"(Y)");
        //Αντικατάσταση του μη τερματικού συμβόλου "Ε" με "(Υ)"
        cout<<generate<<endl;
        //Έκτύπωση της συμβολοσειράς
        test(generate,imax);
        //Επανάληψη αλγορίθμου
    }
    else if(occurrence2!=string::npos){
        generate.replace(occurrence2,1,"AB");
        //Αντικατάσταση του μη τερματικού συμβόλου "Υ" με "ΑΒ"
        cout<<generate<<endl;
        //Έκτύπωση της συμβολοσειράς
        test(generate,imax);
        //Επανάληψη αλγορίθμου
    }
    else if(occurrence3!=string::npos){
        const string left[2]={"v","E"};
        generate.replace(occurrence3,1,left[x]);
        //Αντικατάσταση του μη τερματικού συμβόλου "Α" με "ν" ή με "Ε"
        cout<<generate<<endl;
        //Έκτύπωση της συμβολοσειράς
        test(generate,imax);
        //Επανάληψη αλγορίθμου
    }
    else if(occurrence4!=string::npos){
        const string right[]={"","+Y","-Y"};
        generate.replace(occurrence4,1,right[y]);
        //Αντικατάσταση του μη τερματικού συμβόλου "Β" είτε με κενό (""), είτε με "+Υ", ή με "-Υ"
        cout<<generate<<endl;
        //Έκτύπωση της συμβολοσειράς
        test(generate,imax);
        //Επανάληψη αλγορίθμου
    }
    else{
        //αυτό έιναι το τελικό σημείο του αλγορίθμου, η συμβολοσειρά αποτελείται μόνο από τερματικά σύμβολα
        cout<<generate<<endl;
        //Εκτύπωση της συμβολοσειράς
    }
}

int main() {
    string generate = "E";
    //Εισαγωγή του αρχικού συμβόλου "Ε" στην συμβολοσειρά
    test(generate,0);
    //Εκκίνηση του αλγορίθμου
    return 0;
}
